<?php include('config.php'); ?>
<?php include('sidebar.php'); ?>


<!DOCTYPE html>
<html>
<head>
    <title>Categories</title>
   
</head>
<body>
 
<div class="container mt-5">
    <h2 class="text-center">Manage Categories</h2>

    <!-- Insert Form -->
    <form method="POST" action="">
        <div class="form-group">
            <label>Category Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Phone Number:</label>
            <input type="text" name="phone_number" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description:</label>
            <textarea name="description" class="form-control" rows="3" required></textarea>
        </div>
        <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
    </form>

    <?php
    // Handle Form Submission
    if (isset($_POST['add_category'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $phone_number = $conn->real_escape_string($_POST['phone_number']);
        $description = $conn->real_escape_string($_POST['description']);

        $insertQuery = "INSERT INTO categories (name, phone_number, description) VALUES ('$name', '$phone_number', '$description')";
        if ($conn->query($insertQuery)) {
            echo "<div class='alert alert-success mt-3'>Category added successfully!</div>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Error: " . $conn->error . "</div>";
        }
    }
    ?>

    <!-- Display Categories -->
    <h3 class="mt-5">Category List</h3>
    <table class="table table-bordered mt-3">
        <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Category Name</th>
            <th>Phone Number</th>
            <th>Description</th>
            <th>Created At</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $query = "SELECT * FROM categories";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['phone_number'] . "</td>";
                echo "<td>" . $row['description'] . "</td>";
                echo "<td>" . $row['created_at'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5' class='text-center'>No categories found</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
