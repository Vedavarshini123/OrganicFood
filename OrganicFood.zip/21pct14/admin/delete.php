<style>
  /* General Page Styling */
body {
    background-color: #f4f6f9;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

/* Container Styling */
.container-fluid {
    max-width: 600px;
    margin: 50px auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
    text-align: center;
}

/* Heading */
h2 {
    color: white;
    font-weight: bold;
    margin-bottom: 20px;
}

/* Alert Messages */
.alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 16px;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    width:100%;
    text-align: center;
    font-size: 20px
}

.alert-danger {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* Back Button */
.btn-secondary {
    background: #007BFF;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.3s ease-in-out;
    display: inline-block;
}

.btn-secondary:hover {
    background: #0056b3;
    transform: scale(1.05);
}

</style>
<?php
include('config.php');
include('sidebar.php');


if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Step 1: Delete related records from orders
    $deleteOrders = "DELETE FROM orders WHERE product_id = $id";
    $conn->query($deleteOrders); // Execute deletion

    // Step 2: Delete product after related orders are removed
    $deleteProduct = "DELETE FROM products WHERE id = $id";
    
    if ($conn->query($deleteProduct) === TRUE) {
        echo "<div class='alert alert-success'>Product deleted successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}

$conn->close();
?>
