<?php
include('config.php');
include('sidebar.php');

// Step 1: Verify Database Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Ensure the Database Exists
if (!$conn->select_db('product_management')) {
    die("Failed to select database 'organic_food': " . $conn->error);
}

// Step 3: Debug Table Query
$sql = "SELECT name, email FROM customers";
$result = $conn->query($sql);

// Step 4: Check if Query Execution is Successful
if (!$result) {
    die("Query execution failed: " . $conn->error . " | SQL: " . $sql);
}

// Step 5: Display the Results if Rows Exist
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        td {
            background-color: #f9f9f9;
        }
        tr:nth-child(even) td {
            background-color: #f2f2f2;
        }
        tr:hover td {
            background-color: #e1f5e1;
        }
        @media screen and (max-width: 768px) {
            table, th, td {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Customer List</h1>

    <?php
    // Step 6: Display Data in Table
    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>S.No</th>
                    <th>Username</th>
                    <th>Email</th>
                </tr>";
        $counter = 1;
        while ($customer = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $counter++ . "</td>";
            echo "<td>" . htmlspecialchars($customer['name']) . "</td>";
            echo "<td>" . htmlspecialchars($customer['email']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No customers found.</p>";
    }
    ?>
</div>

</body>
</html>
