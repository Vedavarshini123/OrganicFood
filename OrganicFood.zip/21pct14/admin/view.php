<?php include('config.php'); ?>
<?php include('sidebar.php'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Products</title>
</head>
<body>

<!-- Main Content -->
<div class="container-fluid p-3">
    <h2>All Products</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Subcategory</th> <!-- New column for Subcategory -->
                <th>Price</th>
                <th>Quantity</th>
                <th>Description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch all products from the database
            $sql = "SELECT * FROM products";
            $result = $conn->query($sql);
            $products = [];

            if ($result->num_rows > 0) {
                // Store the products in an array
                while ($row = $result->fetch_assoc()) {
                    $products[] = $row;
                }

                // Quick Sort function to sort products by name
                function quickSort($array) {
                    if(count($array) < 2) {
                        return $array; // Base case: array is already sorted
                    }

                    // Choose a pivot element
                    $pivot = $array[0]['name'];
                    $left = $right = [];

                    // Partition the array into left and right based on the pivot
                    foreach($array as $item) {
                        if(strcmp($item['name'], $pivot) < 0) {
                            $left[] = $item;
                        } else if(strcmp($item['name'], $pivot) > 0) {
                            $right[] = $item;
                        }
                    }

                    // Recursively apply quickSort to the left and right arrays
                    return array_merge(quickSort($left), [$array[0]], quickSort($right));
                }

                // Sort the products by name using Quick Sort
                $products = quickSort($products);

                // Display the sorted products
                foreach ($products as $row) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['category']}</td>
                            <td>{$row['subcategory']}</td> <!-- Display Subcategory -->
                            <td>{$row['price']}</td>
                            <td>{$row['quantity']}</td>
                            <td>{$row['description']}</td>
                            <td>";

                    // Check if the image path exists and display the image
                    if ($row['image_path']) {
                        echo "<img src='{$row['image_path']}' alt='Product Image' width='100' height='100'>";
                    } else {
                        echo "No image";
                    }

                    echo "</td>
                            <td>
                                <a href='update.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete.php?id={$row['id']}' class='btn btn-danger btn-sm'>Delete</a>
                            </td>
                        </tr>";
                }
            } else {
                // Handle no products found case
                echo "<tr><td colspan='9' class='text-center'>No products found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
