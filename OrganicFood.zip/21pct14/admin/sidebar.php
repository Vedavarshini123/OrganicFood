<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="insert.php"><i class="fas fa-plus"></i> Insert Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view.php"><i class="fas fa-eye"></i> View Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="update.php"><i class="fas fa-edit"></i> Update Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="delete.php"><i class="fas fa-trash"></i> Delete Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="orders.php"><i class="fas fa-life-ring"></i> Orders</a>
            </li>
        </ul>
    </div>

    <div class="content">
        <!-- Removed "Welcome to Admin Panel" -->
    </div>

    <style>
        /* General Styles */
        body {
            display: flex;
            min-height: 100vh;
            background-color: #ECF0F1; /* Light background */
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        /* Sidebar Styling */
        #sidebar {
            width: 300px; /* Increased width */
            background-color: #2C3E50; /* Dark Blue */
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            transition: transform 0.3s ease-in-out;
        }

        #sidebar h2 {
            text-align: center;
            font-size: 1.6rem;
            margin-bottom: 20px;
            font-weight: bold;
            border-bottom: 2px solid white;
            padding-bottom: 10px;
        }

        #sidebar ul {
            list-style: none;
            padding: 0;
        }

        #sidebar .nav-link {
            color: white;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease, transform 0.2s;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
        }

        #sidebar .nav-link i {
            margin-right: 10px;
        }

        #sidebar .nav-link:hover {
            background-color: #34495E;
            transform: translateX(5px);
        }

        /* Main Content */
        .content {
            flex-grow: 1;
            padding: 20px;
        }

        /* Responsive Sidebar */
        @media (max-width: 768px) {
            #sidebar {
                width: 80px; /* Sidebar width reduced */
                padding: 10px;
                overflow: hidden;
            }

            #sidebar h2 {
                display: none;
            }

            #sidebar .nav-link {
                text-align: center;
                font-size: 1rem;
                padding: 10px;
                justify-content: center;
            }

            #sidebar .nav-link i {
                margin-right: 0;
            }
        }
    </style>
</body>
</html>
