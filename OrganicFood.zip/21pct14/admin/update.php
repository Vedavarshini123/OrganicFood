<?php 
include('config.php'); 
include('sidebar.php'); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Product</title>
</head>
<body>
    <div class="container-fluid p-3">
        <h2>Update Product</h2>

        <?php
        // Initialize product variable
        $product = [
            'name' => '',
            'category' => '',
            'subcategory' => '',
            'price' => '',
            'quantity' => '',
            'description' => '',
            'image_path' => ''
        ];

        // Fetch product data
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $id = intval($_GET['id']);
            
            $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            
            if (!$product) {
                echo "<div class='alert alert-danger'>Product not found.</div>";
                exit();
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid product ID.</div>";
            exit();
        }

        // Update product details
        if (isset($_POST['update'])) {
            $name = $_POST['name'];
            $category = $_POST['category'];
            $subcategory = $_POST['subcategory'];  
            $price = $_POST['price'];
            $quantity = $_POST['quantity'];
            $description = $_POST['description'];
            $image_path = $product['image_path']; // Retain old image by default

// Check if new image is uploaded
if (!empty($_FILES['image']['name'])) {
    $target_dir = "uploads/"; 
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $image_name = basename($_FILES["image"]["name"]); // Keep the original filename
    $target_file = $target_dir . $image_name;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($imageFileType, $allowed_types)) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            echo "<div class='alert alert-success'>Image uploaded successfully.</div>";
            $image_path = $target_file; // ✅ Update image_path if upload succeeds
        } else {
            echo "<div class='alert alert-danger'>Image upload failed.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Invalid file type. Allowed: jpg, jpeg, png, gif.</div>";
    }
}
            // ✅ Corrected SQL Query and bind_param data types
            $stmt = $conn->prepare("UPDATE products SET name=?, category=?, subcategory=?, price=?, quantity=?, description=?, image_path=? WHERE id=?");
            $stmt->bind_param("sssdissi", $name, $category, $subcategory, $price, $quantity, $description, $image_path, $id);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Product updated successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
            }
        }
        ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Product Name:</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>
            <div class="form-group">
                <label>Category:</label>
                <input type="text" name="category" class="form-control" value="<?= htmlspecialchars($product['category']) ?>" required>
            </div>
            <div class="form-group">
                <label>Subcategory:</label>
                <input type="text" name="subcategory" class="form-control" value="<?= htmlspecialchars($product['subcategory']) ?>" required>
            </div>
            <div class="form-group">
                <label>Price:</label>
                <input type="number" name="price" step="0.01" class="form-control" value="<?= htmlspecialchars($product['price']) ?>" required>
            </div>
            <div class="form-group">
                <label>Quantity:</label>
                <input type="number" name="quantity" class="form-control" value="<?= htmlspecialchars($product['quantity']) ?>" required>
            </div>
            <div class="form-group">
                <label>Description:</label>
                <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($product['description']) ?></textarea>
            </div>
            <div class="form-group">
                <label>Current Image:</label><br>
                <?php if (!empty($product['image_path'])): ?>
                    <img src="<?= htmlspecialchars($product['image_path']) ?>" alt="Product Image" width="100">
                <?php else: ?>
                    <p>No image available.</p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Upload New Image:</label>
                <input type="file" name="image" class="form-control">
            </div>
            <button type="submit" name="update" class="btn btn-primary">Update Product</button>
        </form>
    </div>
</body>
</html>
