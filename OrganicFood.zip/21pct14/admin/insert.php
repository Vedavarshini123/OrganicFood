<?php include('config.php'); ?>
<?php include('sidebar.php'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Insert Product</title>
</head>
<body>

<!-- Main Content -->
<div class="container-fluid p-3">
    <h2>Add New Product</h2>
    <form action="insert.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Product Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Category:</label>
            <select name="category" class="form-control" required>
                <option value="" disabled selected>Select a category</option>
                <option value="Fruits">Fruits</option>
                <option value="Vegetables">Vegetables</option>
            </select>
        </div>
        <div class="form-group">
            <label>Subcategory (Type/Variety):</label>
            <input type="text" name="subcategory" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Price:</label>
            <input type="number" name="price" step="0.01" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Quantity:</label>
            <input type="number" name="quantity" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description:</label>
            <textarea name="description" class="form-control" rows="4"></textarea>
        </div>
        <div class="form-group">
            <label>Image:</label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Add Product</button>
    </form>
</div>

<?php
if (isset($_POST['submit'])) {
    // Capture form data
    $name = $_POST['name'];
    $category = $_POST['category'];
    $subcategory = $_POST['subcategory'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $description = $_POST['description'];

    // Handle Image Upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = $_FILES['image']['name'];
        $target_dir = "uploads/"; // Directory to store uploaded images
        $target_file = $target_dir . basename($image);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is an image
        if (getimagesize($_FILES['image']['tmp_name']) === false) {
            echo "File is not an image.";
            exit;
        }

        // Check file size (limit to 5MB)
        if ($_FILES['image']['size'] > 5000000) {
            echo "Sorry, your file is too large.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit;
        }

        // Resize image to a fixed size (e.g., 300x300 pixels)
        $desiredWidth = 300;
        $desiredHeight = 300;

        // Create an image resource based on file type
        $sourceImage = null;
        if ($imageFileType == "jpg" || $imageFileType == "jpeg") {
            $sourceImage = imagecreatefromjpeg($_FILES['image']['tmp_name']);
        } elseif ($imageFileType == "png") {
            $sourceImage = imagecreatefrompng($_FILES['image']['tmp_name']);
        } elseif ($imageFileType == "gif") {
            $sourceImage = imagecreatefromgif($_FILES['image']['tmp_name']);
        }

        // Create a new blank image with the desired dimensions
        $resizedImage = imagecreatetruecolor($desiredWidth, $desiredHeight);

        // Copy and resize the original image into the blank image
        list($originalWidth, $originalHeight) = getimagesize($_FILES['image']['tmp_name']);
        imagecopyresampled($resizedImage, $sourceImage, 0, 0, 0, 0, $desiredWidth, $desiredHeight, $originalWidth, $originalHeight);

        // Save the resized image back to the uploads directory
        if ($imageFileType == "jpg" || $imageFileType == "jpeg") {
            imagejpeg($resizedImage, $target_file);
        } elseif ($imageFileType == "png") {
            imagepng($resizedImage, $target_file);
        } elseif ($imageFileType == "gif") {
            imagegif($resizedImage, $target_file);
        }

        // Free up memory
        imagedestroy($sourceImage);
        imagedestroy($resizedImage);

        echo "The file " . htmlspecialchars(basename($image)) . " has been uploaded and resized.";
    }

    // Insert into database including image path
    $sql = "INSERT INTO products (name, category, subcategory, price, quantity, description, image_path)
            VALUES ('$name', '$category', '$subcategory', '$price', '$quantity', '$description', '$target_file')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product added successfully'); window.location.href='view.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

</body>
</html>
