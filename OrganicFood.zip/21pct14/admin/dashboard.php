<?php
session_start();
include('config.php');
include('sidebar.php');


// Check if admin is logged in
if (!isset($_SESSION['admin_user'])) {
    header("Location: index.php");
    exit();
}

// Fetch Total Products
$productQuery = "SELECT COUNT(*) AS total_products FROM product_management.products"; 
$productResult = $conn->query($productQuery);
$productData = $productResult->fetch_assoc();

// Fetch Total Orders
$orderQuery = "SELECT COUNT(*) AS total_orders FROM product_management.orders";
$orderResult = $conn->query($orderQuery);
$orderData = $orderResult->fetch_assoc();

// Fetch Total Customers
$customerQuery = "SELECT COUNT(*) AS total_customers FROM product_management.customers";
$customerResult = $conn->query($customerQuery);
$customerData = $customerResult->fetch_assoc();
// Fetch Product Sales Data
$salesQuery = "SELECT p.name AS product_name, COUNT(o.product_id) AS purchase_count 
               FROM product_management.orders o 
               JOIN product_management.products p ON o.product_id = p.id
               GROUP BY o.product_id";
$salesResult = $conn->query($salesQuery);
$products = [];
$purchases = [];
while ($row = $salesResult->fetch_assoc()) {
    $products[] = htmlspecialchars($row['product_name']);
    $purchases[] = $row['purchase_count'];
}

// Fetch Weekly User Registrations Data
$registrationQuery = "SELECT DATE(created_at) as reg_date, COUNT(*) as user_count 
                      FROM product_management.customers 
                      WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                      GROUP BY reg_date";
$registrationResult = $conn->query($registrationQuery);
$dates = [];
$registrations = [];
while ($row = $registrationResult->fetch_assoc()) {
    $dates[] = $row['reg_date'];
    $registrations[] = $row['user_count'];
}
// Fetch Revenue Data
$revenueQuery = "SELECT DATE(order_date) as order_date, SUM(total_price) as total_revenue 
                 FROM product_management.orders 
                 WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                 GROUP BY order_date";
$revenueResult = $conn->query($revenueQuery);
$revenueDates = [];
$revenues = [];
while ($row = $revenueResult->fetch_assoc()) {
    $revenueDates[] = $row['order_date'];
    $revenues[] = $row['total_revenue'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
        }
       
        /* Main Content */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #f8f9fa;
        }
        .dashboard-title {
            font-weight: bold;
            font-size: 2rem;
            color: #333;
        }

        /* Navbar */
        .navbar {
            background-color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .navbar a {
            text-decoration: none;
            color: black;
            font-weight: bold;
        }
        .navbar .logout-btn {
            background: red;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }
        .navbar .logout-btn:hover {
            background: darkred;
        }

        /* Cards */
        .card {
            color: white;
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }
        .bg-blue { background-color: #007bff; }
        .bg-green { background-color: #28a745; }
        .bg-red { background-color: #dc3545; }
    </style>
</head>
<body>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <div class="navbar">
            <span>Welcome, <strong>Admin</strong></span>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <h2 class="dashboard-title">Dashboard</h2>
        <div class="row">
            <!-- Total Products -->
            <div class="col-md-3 mb-4">
                <div class="card bg-blue p-3">
                    <i class="fas fa-tasks fa-2x"></i>
                    <h5 class="mt-3">Products</h5>
                    <h2><?= $productData['total_products']; ?></h2>
                    <a href="view.php" class="text-white">View Details <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- Total Customers -->
            <div class="col-md-3 mb-4">
                <div class="card bg-green p-3">
                    <i class="fas fa-users fa-2x"></i>
                    <h5 class="mt-3">Customers</h5>
                    <h2><?= $customerData['total_customers']; ?></h2>
                    <a href="customers.php" class="text-white">View Details <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- Total Orders -->
            <div class="col-md-3 mb-4">
                <div class="card bg-red p-3">
                    <i class="fas fa-life-ring fa-2x"></i>
                    <h5 class="mt-3">Orders</h5>
                    <h2><?= $orderData['total_orders']; ?></h2>
                    <a href="orders.php" class="text-white">View Details <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <canvas id="productSalesChart"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="userRegistrationChart"></canvas>
            </div>
             <div class="col-md-12">
                <div style="height: 300px; width: 100%;">
                <canvas id="revenueChart"></canvas>
            </div>
            
        </div>

    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const productSalesCtx = document.getElementById('productSalesChart').getContext('2d');
        new Chart(productSalesCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($products) ?>,
                datasets: [{
                    label: 'Product Purchases',
                    data: <?= json_encode($purchases) ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });

        const userRegCtx = document.getElementById('userRegistrationChart').getContext('2d');
        new Chart(userRegCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($dates) ?>,
                datasets: [{
                    label: 'Weekly Registrations',
                    data: <?= json_encode($registrations) ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($revenueDates) ?>,
                datasets: [{
                    label: 'Daily Revenue',
                    data: <?= json_encode($revenues) ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });
    });
</script>

</html>

    
  