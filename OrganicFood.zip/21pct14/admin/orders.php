<?php
include('config.php');
include('sidebar.php');
session_start();

// Fetch all orders from the database
$orderQuery = "SELECT o.id, p.name AS product_name, o.quantity, o.total_price, o.order_date, o.customer_id, o.address 
               FROM product_management.orders o
               JOIN product_management.products p ON o.product_id = p.id";

$orderResult = $conn->query($orderQuery);

if (!$orderResult) {
    die('Error fetching orders: ' . $conn->error);
}

// Store orders in an array for sorting
$orders = [];
while ($row = $orderResult->fetch_assoc()) {
    $orders[] = $row;
}

// Bubble Sort Algorithm to sort orders by ID (Ascending)
$n = count($orders);
for ($i = 0; $i < $n - 1; $i++) {
    for ($j = 0; $j < $n - $i - 1; $j++) {
        if ($orders[$j]['id'] > $orders[$j + 1]['id']) {
            $temp = $orders[$j];
            $orders[$j] = $orders[$j + 1];
            $orders[$j + 1] = $temp;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .table-container {
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            width: 98%;
            max-width: 100%;
            display: flex;
            justify-content: center;
        }

        table {
            width: 95%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
        }

        thead th {
            background: linear-gradient(135deg, #007BFF, #0056b3);
            color: white;
            padding: 12px;
            font-size: 16px;
            text-align: center;
        }

        tbody td {
            text-align: center;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        tbody tr:nth-child(even) {
            background: #f8f9fa;
        }

        tbody tr:hover {
            background: #e9f5ff;
            transform: scale(1.01);
            transition: all 0.2s ease-in-out;
        }

        @media (max-width: 768px) {
            .table-container {
                padding: 15px;
            }

            table {
                font-size: 14px;
            }

            thead th {
                padding: 10px;
            }

            tbody td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="table-container">
        <h2>Order Details</h2>
        <table class="table table-striped table-bordered w-100">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Product Name</th>
                    <th>Customer ID</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                    <th>Address</th> <!-- Added Address Column -->
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($orders)) {
                    foreach ($orders as $order) {
                        echo "<tr>
                                <td>{$order['id']}</td>
                                <td>{$order['product_name']}</td>
                                <td>{$order['customer_id']}</td>
                                <td>{$order['quantity']}</td>
                                <td>Rs. {$order['total_price']}</td>
                                <td>{$order['order_date']}</td>
                                <td>{$order['address']}</td> <!-- Display Address -->
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No orders have been placed yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
