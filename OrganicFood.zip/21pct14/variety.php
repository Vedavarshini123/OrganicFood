<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variety Details</title>
    <style>
      body {
    font-family: 'Arial', sans-serif;
    padding: 20px;
    background-color: #f9f9f9;
    margin: 0;
    }

    .container {
        max-width: 90%;
        margin: auto;
        padding: 20px;
        background: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    h2 {
        color: #387a17;
        text-align: center;
        margin-bottom: 20px;
        font-size: 2rem;
    }

    h3 {
        color: #2f5d10;
        margin-top: 20px;
        border-bottom: 2px solid #387a17;
        padding-bottom: 5px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        overflow: hidden;
        border-radius: 8px;
    }

    th, td {
        padding: 12px;
        text-align: center;
        border: 1px solid #ccc;
    }

    th {
        background-color: #e8f5e9;
        color: #387a17;
        font-weight: bold;
    }

    tr:nth-child(even) {
        background-color: #f1f8f4;
    }

    tr:hover {
        background-color: #d7f0dc;
        transition: background 0.3s ease-in-out;
    }

    .btn {
        display: inline-block;
        padding: 8px 12px;
        color: white;
        background-color: #387a17;
        text-decoration: none;
        border-radius: 5px;
        transition: all 0.3s ease-in-out;
    }

    .btn:hover {
        background-color: #2d6113;
        transform: scale(1.05);
    }
</style>
</head>
<body>
    <div class="container">
        <h2>Variety Details</h2>

        <!-- Mango Table -->
        <h3>Mango</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Subcategory</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Alphonso Mango</td>
                <td>Fruits</td>
                <td>Premium Variety</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Kesar Mango</td>
                <td>Fruits</td>
                <td>Saffron-Flavored</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Amrapali Mango</td>
                <td>Fruits</td>
                <td>Dwarf Hybrid</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
        </table>

        <!-- Potato Table -->
        <h3>Potato</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Subcategory</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Sweet Potato</td>
                <td>Vegetables</td>
                <td>High in Fiber</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Baby Potato</td>
                <td>Vegetables</td>
                <td>Small & Tender</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
        </table>

        <!-- Carrot Table -->
        <h3>Carrot</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Subcategory</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Baby Carrot</td>
                <td>Vegetables</td>
                <td>Snack-Size</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Purple Carrot</td>
                <td>Vegetables</td>
                <td>Rich in Antioxidants</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Danvers Carrot</td>
                <td>Vegetables</td>
                <td>Thick & Sweet</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
        </table>

        <!-- Berries Table -->
        <h3>Berries</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Subcategory</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Strawberry</td>
                <td>Fruits</td>
                <td>Soft & Juicy</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Blueberry</td>
                <td>Fruits</td>
                <td>Antioxidant Rich</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
            <tr>
                <td>Cranberry</td>
                <td>Fruits</td>
                <td>Tart & Nutrient-Dense</td>
                <td><a href="shop.php" class="btn">Shop</a></td>
            </tr>
        </table>
    </div>
</body>
</html>
