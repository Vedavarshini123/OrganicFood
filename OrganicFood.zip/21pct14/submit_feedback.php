<?php
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_POST['customer_id']; // Replace with session user ID
    $rating = $_POST['rating'];
    $review = $_POST['review'];
    $created_at = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("INSERT INTO rating (customer_id, rating, review, created_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $customer_id, $rating, $review, $created_at);

    if ($stmt->execute()) {
        echo "Thank you for your feedback!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
