<?php
session_start();
include('config.php'); // Ensure DB connection

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['product_id'];
    if (isset($_POST['increase'])) {
        $_SESSION['cart'][$id]++; // Increase quantity
    } elseif (isset($_POST['decrease'])) {
        if ($_SESSION['cart'][$id] > 1) {
            $_SESSION['cart'][$id]--; // Decrease quantity
        } else {
            unset($_SESSION['cart'][$id]); // Remove if quantity is 1
        }
    }
    header("Location: cart.php");
    exit;
}

// Get the entered address
$address = isset($_POST['address']) ? trim($_POST['address']) : null;

if ($address) {
    // Insert address into `orders` table
    $stmt = $conn->prepare("INSERT INTO orders (customer_id, address, order_date) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $customer_id, $address);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to right, #A8E6CF, #D4FC79);
            padding-top: 50px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            max-width: 900px;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            font-size: 28px;
            font-weight: 600;
            color: #2d3436;
            margin-bottom: 20px;
        }

        .cart-total {
            font-size: 20px;
            font-weight: bold;
            text-align: right;
            color: #222;
        }

        .address-box {
            margin-top: 20px;
        }

        #address {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 10px;
        }

        #map {
            width: 100%;
            height: 300px;
            border-radius: 8px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Your Shopping Cart</h2>

    <div class="table-responsive">
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach ($_SESSION['cart'] as $id => $qty) {
                    $sql = "SELECT name, price FROM products WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($row = $result->fetch_assoc()) {
                        $subtotal = $row['price'] * $qty;
                        $total += $subtotal;
                        echo "<tr>
                            <td>{$row['name']}</td>
                            <td>Rs. {$row['price']}</td>
                            <td>
                                <form method='POST' class='d-flex justify-content-center align-items-center'>
                                    <input type='hidden' name='product_id' value='{$id}'>
                                    <button type='submit' name='decrease' class='btn btn-warning mx-1'>-</button>
                                    <span class='px-2 fw-bold'>{$qty}</span>
                                    <button type='submit' name='increase' class='btn btn-success mx-1'>+</button>
                                </form>
                            </td>
                            <td>Rs. {$subtotal}</td>
                            <td>
                                <a href='remove.php?id={$id}' class='btn btn-danger btn-sm'>Remove</a>
                            </td>
                        </tr>";
                    }
                }
                ?>
                <tr>
                    <td colspan="3" class="cart-total">Total</td>
                    <td><strong>Rs. <?php echo $total; ?></strong></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Address Input -->
    <div class="address-box">
        <form action="cartorder.php" method="POST">
            <label for="address" class="form-label">Enter Delivery Address:</label>
            <input type="text" id="address" name="address" placeholder="Enter your full address..." required>

            <!-- Google Map -->
            <div id="map"></div>

            <button type="submit" class="btn btn-primary mt-3">Confirm Order</button>
        </form>
    </div>
</div>

<!-- JavaScript to Make Map Interactive -->
<script>
    let map, marker;

    function initMap() {
        let defaultLocation = { lat: 28.7041, lng: 77.1025 }; // New Delhi, India
        
        map = new google.maps.Map(document.getElementById("map"), {
            center: defaultLocation,
            zoom: 15,
        });

        marker = new google.maps.Marker({
            position: defaultLocation,
            map: map,
            draggable: true
        });

        marker.addListener("dragend", function () {
            let position = marker.getPosition();
            getAddress(position.lat(), position.lng());
        });

        map.addListener("click", function (event) {
            let lat = event.latLng.lat();
            let lng = event.latLng.lng();
            marker.setPosition({ lat, lng });
            getAddress(lat, lng);
        });

        document.getElementById("address").addEventListener("change", function () {
            let address = document.getElementById("address").value;
            updateMap(address);
        });
    }

    function getAddress(lat, lng) {
        let geocodeUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`;

        fetch(geocodeUrl)
            .then(response => response.json())
            .then(data => {
                let address = data.display_name;
                document.getElementById("address").value = address;
            })
            .catch(error => console.log("Error fetching address:", error));
    }

    function updateMap(address) {
        let mapUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`;

        fetch(mapUrl)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    let lat = parseFloat(data[0].lat);
                    let lng = parseFloat(data[0].lon);
                    map.setCenter({ lat, lng });
                    marker.setPosition({ lat, lng });
                }
            })
            .catch(error => console.log("Error fetching location:", error));
    }
</script>

<!-- Load Google Maps (Without API Key) -->
<script async defer src="https://maps.googleapis.com/maps/api/js?callback=initMap"></script>

</body>
</html>
