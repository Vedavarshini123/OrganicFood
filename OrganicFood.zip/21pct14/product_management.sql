-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2025 at 08:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '7676aaafb027c825bd9abab78b234070e702752f625b752e55e55b48e607e358');

-- --------------------------------------------------------

--
-- Table structure for table `cartorder`
--

CREATE TABLE `cartorder` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `phone_number`, `description`, `created_at`) VALUES
(1, 'Vegetable', '07397389585', 'fef', '2024-12-20 16:29:56');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `Number` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `password`, `Number`, `created_at`) VALUES
(1, 'veda', '21pct14@wcc.edu.in', '123', '0', '2025-03-15 16:56:44'),
(2, 'ramya', 'jinendradhanaraj@gmail.com', '345', '0', '2025-03-15 16:56:44'),
(3, 'Nitin', 'nitinaraynal@gmail.com', '567', '2147483647', '2025-03-15 16:56:44'),
(5, 'roshan', 'ros@gmail.com', '777', '2147483647', '2025-03-15 16:56:44'),
(6, 'Ramya', 'ramya@gmail.com', '444', '2147483647', '2025-03-15 16:56:44'),
(7, 'Kausi', 'kausi@gmail.com', '777', '2147483647', '2025-03-16 03:25:47'),
(8, 'Kanimozhi', 'kani@gmail.com', '0000', '2147483647', '2025-03-16 05:40:06'),
(9, 'Praveen', 'praveen@gmail.com', '222', '2147483647', '2025-03-16 05:43:12'),
(11, 'Priyanka', 'priyanka01@gmail.com', '4444', '2147483647', '2025-03-18 07:48:56'),
(12, 'Ashika', 'ashika@gmail.com', '123', '2147483647', '2025-03-18 09:21:00'),
(14, 'Ash', 'as@gmail.com', '123', '9089898989', '2025-03-18 09:25:05'),
(15, 'Akash', 'akash@gmail.com', '666', '7845129687', '2025-03-18 09:33:09');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `product_id`, `customer_id`, `order_date`, `quantity`, `total_price`, `address`) VALUES
(1, 6, 1, '2024-12-25', 3, 90.00, NULL),
(2, 6, 1, '2024-12-28', 1, 30.00, NULL),
(3, 6, 1, '2025-01-12', 1, 30.00, NULL),
(4, 6, 1, '2025-01-12', 1, 30.00, NULL),
(5, 9, 1, '2025-01-12', 1, 40.00, NULL),
(6, 6, 1, '2025-01-12', 1, 30.00, NULL),
(7, 6, 1, '2025-01-12', 1, 30.00, NULL),
(8, 6, 1, '2025-01-12', 1, 30.00, NULL),
(9, 9, 1, '2025-01-12', 1, 40.00, NULL),
(10, 10, 1, '2025-01-13', 2, 240.00, NULL),
(11, 14, 1, '2025-01-13', 5, 750.00, NULL),
(12, 8, 1, '2025-02-24', 1, 100.00, NULL),
(14, 10, 1, '2025-02-24', 1, 120.00, NULL),
(16, 10, 1, '2025-02-24', 2, 240.00, NULL),
(17, 15, 1, '2025-02-25', 4, 400.00, NULL),
(18, 16, 1, '2025-02-25', 3, 120.00, NULL),
(23, 14, 1, '2025-03-15', 1, 150.00, NULL),
(24, 14, 1, '2025-03-15', 2, 300.00, NULL),
(25, 15, 1, '2025-03-15', 1, 100.00, NULL),
(28, 15, 1, '2025-03-15', 1, 100.00, NULL),
(29, 17, 1, '2025-03-15', 1, 70.00, NULL),
(31, 16, 1, '2025-03-15', 2, 80.00, NULL),
(32, 16, 1, '2025-03-15', 1, 40.00, NULL),
(33, 15, 1, '2025-03-15', 1, 100.00, NULL),
(35, 14, 1, '2025-03-15', 1, 150.00, NULL),
(36, 14, 1, '2025-03-15', 1, 150.00, NULL),
(37, 10, 1, '2025-03-15', 1, 120.00, NULL),
(38, 17, 1, '2025-03-15', 2, 140.00, NULL),
(40, 17, 1, '2025-03-15', 2, 140.00, NULL),
(41, 10, 1, '2025-03-15', 1, 120.00, NULL),
(42, 17, 1, '2025-03-15', 1, 70.00, NULL),
(43, 18, 1, '2025-03-15', 1, 95.00, NULL),
(44, 16, 1, '2025-03-16', 1, 40.00, NULL),
(45, 15, 1, '2025-03-16', 1, 100.00, NULL),
(46, 18, 1, '2025-03-16', 9, 855.00, NULL),
(47, 17, 1, '2025-03-16', 1, 70.00, NULL),
(48, 17, 1, '2025-03-16', 1, 70.00, NULL),
(49, 15, 1, '2025-03-16', 1, 100.00, NULL),
(50, 16, 1, '2025-03-16', 1, 40.00, NULL),
(51, 14, 1, '2025-03-16', 1, 150.00, NULL),
(52, 14, 1, '2025-03-17', 2, 300.00, NULL),
(53, 8, 1, '2025-03-18', 2, 200.00, NULL),
(54, 8, 1, '2025-03-18', 1, 100.00, NULL),
(55, 8, 1, '2025-03-18', 2, 200.00, NULL),
(56, 8, 1, '2025-03-18', 1, 100.00, NULL),
(57, 17, 1, '2025-03-18', 2, 140.00, 'Kilpauk'),
(58, 10, 1, '2025-03-18', 1, 120.00, NULL),
(60, 8, 1, '2025-03-18', 1, 100.00, NULL),
(61, 18, 1, '2025-03-18', 1, 95.00, NULL),
(62, 21, 1, '2025-03-18', 1, 250.00, 'Pammal, Pallavaram, Chengalpattu, Tamil Nadu, 600043, India'),
(63, 10, 1, '2025-03-18', 1, 120.00, 'vadapalani'),
(64, 19, 1, '2025-03-18', 1, 240.00, 'North Mada Street, Ward 130, Zone 10 Kodambakkam, Chennai, Tamil Nadu, 600001, India'),
(65, 22, 1, '2025-03-18', 2, 500.00, 'Harleys Road, Kellys, Ward 103, Zone 8 Anna Nagar, Chennai, Tamil Nadu, 600001, India'),
(66, 18, 1, '2025-03-18', 4, 380.00, 'Villivakkam'),
(67, 21, 1, '2025-03-18', 1, 250.00, 'villivakkam'),
(68, 14, 1, '2025-03-18', 2, 300.00, 'Pammal, Pallavaram, Chengalpattu, Tamil Nadu, 600075, India'),
(69, 8, 1, '2025-04-09', 1, 100.00, 'wcc'),
(70, 6, 1, '2025-06-23', 1, 30.00, 'Harleys Road, Kellys, Ward 103, Zone 8 Anna Nagar, Chennai, Tamil Nadu, 600001, India'),
(71, 8, 1, '2025-06-23', 1, 100.00, 'Pammal');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `subcategory`, `price`, `quantity`, `description`, `image_path`, `image`) VALUES
(6, 'Carrot', 'Vegetables', 'Danvers Carrot', 30.00, 0, 'Glow skin', 'uploads/carrot.jpeg', ''),
(8, 'Kesar Mango', 'Fruits', 'Kesar', 100.00, 1, 'Saffron-Flavored', 'uploads/kesar.jpg', '1742261309_kesar.jpg'),
(9, 'Cucumber', 'Fruits', 'raw', 40.00, 0, 'Hydrating', 'uploads/cucumber.jpg', ''),
(10, 'Alphanso Mango', 'Fruits', 'Alphanso', 120.00, 18, 'Sweeter than usual Mango', 'uploads/Alphanso.jpg', ''),
(14, 'Amarapalli', 'Fruits', 'Amarapalli mango', 150.00, 18, 'High content of vitamin A', 'uploads/Amarapalli.jpg', ''),
(15, 'Purple Potato', 'Vegetables', 'Purple potato', 100.00, 2, 'High fibre content', 'uploads/Purple potato.jpg', ''),
(16, 'Sweet Potato', 'Vegetables', 'Root', 40.00, 7, 'Good for constipation\r\nPromotes weight gain', 'uploads/sweet.JPG', ''),
(17, 'Greens-Spinach', 'Vegetables', 'Spinach', 70.00, 15, 'Rich in magnesium', 'uploads/spinach.jpg', ''),
(18, 'Broccoli', 'Vegetables', 'Greens', 95.00, 45, 'High in fiber', 'uploads/broccolli.jpg', ''),
(19, 'Strawberry', 'Fruits', 'Strawberry', 240.00, 49, 'Good for health', 'uploads/strawberry.jpg', ''),
(21, 'Blueberry', 'Fruits', 'Berries', 250.00, 28, 'Antioxident-rich', 'uploads/blueberry.jpg', ''),
(22, 'Cranberry', 'Fruits', 'Berries', 250.00, 28, 'Nutrient-Dense', 'uploads/cranberry.jpeg', '');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `review` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `product_id`, `customer_id`, `rating`, `review`, `created_at`) VALUES
(1, 13, 1, 4, 'Best', '2025-02-24 17:04:10'),
(2, 10, 1, 5, 'nie', '2025-02-24 17:20:22'),
(3, 15, 1, 5, 'Excellent', '2025-02-25 02:31:03'),
(4, 13, 1, 5, 'Good', '2025-02-25 10:47:13'),
(5, 14, 1, 5, 'Excellent', '2025-03-15 13:15:47'),
(6, 15, 1, 4, 'Very useful', '2025-03-15 13:19:58'),
(7, 15, 1, 5, 'Excellent', '2025-03-16 08:38:47'),
(8, 19, 1, 5, 'Excellent', '2025-03-18 03:39:24'),
(9, 21, 1, 4, 'very good', '2025-03-18 07:55:37'),
(10, 8, 1, 5, 'good', '2025-04-09 06:10:21'),
(11, 6, 1, 5, 'Excellent', '2025-06-23 17:44:34'),
(12, 8, 1, 5, 'Good', '2025-06-23 17:45:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cartorder`
--
ALTER TABLE `cartorder`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cartorder`
--
ALTER TABLE `cartorder`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cartorder`
--
ALTER TABLE `cartorder`
  ADD CONSTRAINT `cartorder_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `cartorder_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
